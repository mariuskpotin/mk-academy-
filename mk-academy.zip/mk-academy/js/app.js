// ============================================================
// MK ACADEMY — APP.JS
// Logique principale : auth, navigation, quiz, flashcards...
// ============================================================

// ── STORAGE HELPERS ──────────────────────────────────────────
const DB = {
  get: k => { try { return JSON.parse(localStorage.getItem('mk_'+k)); } catch(e){ return null; } },
  set: (k,v) => localStorage.setItem('mk_'+k, JSON.stringify(v)),
  del: k => localStorage.removeItem('mk_'+k),
};

// ── INITIAL SETUP ────────────────────────────────────────────
let currentUser = null;
let allUsers = DB.get('users') || [];
let appPrices = DB.get('prices') || MK.PRICES;

// Crée le compte admin Marius si inexistant
function ensureAdmin(){
  const exists = allUsers.find(u => u.email === MK.ADMIN_EMAIL);
  if(!exists){
    allUsers.push({
      id: 'admin',
      name: 'Marius KPOTIN',
      email: MK.ADMIN_EMAIL,
      password: 'mk2024admin',
      role: 'admin',
      lang: 'en',
      xp: 0, streak: 0, coins: 0,
      lessons_done: [],
      daily_done: 0,
      premium: true,
      joined: new Date().toISOString(),
      last_login: null,
    });
    DB.set('users', allUsers);
  }
}

// ── AUTH ──────────────────────────────────────────────────────
function doLogin(){
  const email = document.getElementById('login-email').value.trim();
  const pass  = document.getElementById('login-pass').value.trim();
  if(!email || !pass){ toast('⚠️ Remplis tous les champs'); return; }
  const user = allUsers.find(u => u.email===email && u.password===pass);
  if(!user){ toast('❌ Email ou mot de passe incorrect'); return; }
  user.last_login = new Date().toISOString();
  DB.set('users', allUsers);
  DB.set('current_user', user.id);
  currentUser = user;
  afterLogin();
}

function doRegister(){
  const name  = document.getElementById('reg-name').value.trim();
  const email = document.getElementById('reg-email').value.trim();
  const pass  = document.getElementById('reg-pass').value.trim();
  const lang  = document.getElementById('reg-lang').value;
  if(!name||!email||!pass){ toast('⚠️ Remplis tous les champs'); return; }
  if(allUsers.find(u=>u.email===email)){ toast('❌ Email déjà utilisé'); return; }
  const user = {
    id: 'u_'+Date.now(),
    name, email, password: pass,
    role: 'user', lang,
    xp:0, streak:0, coins:0,
    lessons_done:[], daily_done:0,
    premium: false,
    joined: new Date().toISOString(),
    last_login: new Date().toISOString(),
  };
  allUsers.push(user);
  DB.set('users', allUsers);
  DB.set('current_user', user.id);
  currentUser = user;
  toast('✅ Compte créé avec succès !');
  afterLogin();
}

function afterLogin(){
  document.getElementById('bottom-nav').classList.remove('hidden');
  showScreen('s-app');
  refreshHomeUI();
  buildModules();
  buildLearnTab();
  buildVocabTab();
  buildQuizTab();
  buildProfileTab();
  applyTranslations();
  if(currentUser.role==='admin') showAdminBadge();
}

function doLogout(){
  DB.del('current_user');
  currentUser = null;
  document.getElementById('bottom-nav').classList.add('hidden');
  showScreen('s-auth');
  showLogin();
}

function showLogin(){
  document.getElementById('auth-login').classList.remove('hidden');
  document.getElementById('auth-register').classList.add('hidden');
}
function showRegister(){
  document.getElementById('auth-login').classList.add('hidden');
  document.getElementById('auth-register').classList.remove('hidden');
}

// ── NAVIGATION ────────────────────────────────────────────────
function showScreen(id){
  document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));
  document.getElementById(id).classList.add('active');
}

function showTab(tab){
  ['home','learn','vocab','quiz','profile'].forEach(t=>{
    document.getElementById('tab-'+t).classList.add('hidden');
    document.getElementById('bnav-'+t)?.classList.remove('active');
  });
  document.getElementById('tab-'+tab).classList.remove('hidden');
  document.getElementById('bnav-'+tab)?.classList.add('active');
  window.scrollTo(0,0);
}

function goApp(){ showScreen('s-app'); }
function goAdmin(){ buildAdminPanel(); showScreen('s-admin'); }

// ── HOME UI ───────────────────────────────────────────────────
function refreshHomeUI(){
  if(!currentUser) return;
  document.getElementById('home-username').textContent = currentUser.name.split(' ')[0];
  document.getElementById('topbar-avatar').textContent = currentUser.name[0].toUpperCase();
  document.getElementById('topbar-coins').textContent = '🪙 '+currentUser.coins;
  document.getElementById('streak-count').textContent = currentUser.streak+' 🔥';
  document.getElementById('xp-count').textContent = currentUser.xp;
  const done = currentUser.daily_done || 0;
  const goal = 5;
  document.getElementById('daily-progress-txt').textContent = done+'/'+goal+' '+t('nav_learn');
  document.getElementById('daily-bar').style.width = Math.min(100,done/goal*100)+'%';
  const lang = MK.LANGUAGES[currentUser.lang]||MK.LANGUAGES.en;
  document.getElementById('home-lang-flag').textContent = lang.flag;
  document.getElementById('home-lang-name').textContent = lang.name;
  document.getElementById('home-lang-level').textContent = t('level')+' '+(currentUser.premium?'Premium':'Débutant');
}

function showAdminBadge(){
  const tb = document.querySelector('.topbar-logo');
  if(tb) tb.innerHTML = 'MK ACADEMY <span style="font-size:10px;color:var(--o);margin-left:4px" onclick="goAdmin()">⚙️ ADMIN</span>';
}

// ── MODULES ───────────────────────────────────────────────────
function buildModules(){
  const grid = document.getElementById('modules-grid');
  grid.innerHTML = '';
  const modLabels = {
    alphabet:t('mod_alphabet'), basics:t('mod_basics'),
    grammar:t('mod_grammar'), vocab:t('mod_vocab'),
    listening:t('mod_listening'), science:t('mod_science'),
  };
  MK.MODULES.forEach(m=>{
    const locked = !m.free && !currentUser?.premium;
    const div = document.createElement('div');
    div.style.cssText = `background:var(--card);border:1px solid ${locked?'var(--bord)':m.color+'44'};border-radius:14px;padding:16px;cursor:pointer;position:relative;transition:all .2s`;
    div.innerHTML = `
      <div style="font-size:28px;margin-bottom:8px">${m.icon}</div>
      <div style="font-size:13px;font-weight:bold;margin-bottom:4px">${modLabels[m.id]||m.id}</div>
      <span style="font-size:9px;padding:2px 7px;border-radius:99px;background:${locked?'#ff5a7a20':'#00e5a020'};color:${locked?'var(--r)':'var(--g)'}">
        ${locked?'🔒 PREMIUM':'✓ GRATUIT'}</span>
      ${locked?'<div style="position:absolute;inset:0;border-radius:14px;background:#0008"></div>':''}`;
    div.onclick = () => {
      if(locked){ toast('🔒 '+t('locked_msg')); return; }
      if(m.id==='vocab') showTab('vocab');
      else if(m.id==='grammar') showTab('learn');
      else showTab('learn');
    };
    grid.appendChild(div);
  });
}

// ── LEARN TAB ─────────────────────────────────────────────────
function buildLearnTab(){
  const lang = currentUser?.lang || 'en';
  const lessons = MK.LESSONS[lang] || MK.LESSONS.en;
  const content = document.getElementById('learn-content');
  content.innerHTML = '';

  // Plan 60 jours
  const planDiv = document.createElement('div');
  planDiv.style.marginBottom = '20px';
  planDiv.innerHTML = `<div style="font-size:13px;font-weight:bold;color:var(--muted);margin-bottom:10px;letter-spacing:1px">${t('plan_title').toUpperCase()}</div>`;
  const planTabs = document.createElement('div');
  planTabs.style.cssText = 'display:flex;gap:6px;overflow-x:auto;margin-bottom:12px;padding-bottom:4px';
  const planContent = document.createElement('div');

  MK.PLAN.forEach((ph,i)=>{
    const btn = document.createElement('button');
    btn.className = 'btn btn-sm';
    btn.style.cssText = `white-space:nowrap;background:${i===0?ph.color:'var(--card)'};color:${i===0?'#000':'var(--muted)'};border:1px solid ${i===0?ph.color:'var(--bord)'}`;
    btn.textContent = ph.icon+' Phase '+ph.phase;
    btn.onclick = ()=>{
      planTabs.querySelectorAll('button').forEach((b,j)=>{
        b.style.background = j===i?MK.PLAN[j].color:'var(--card)';
        b.style.color = j===i?'#000':'var(--muted)';
        b.style.borderColor = j===i?MK.PLAN[j].color:'var(--bord)';
      });
      renderPlanPhase(ph, planContent);
    };
    planTabs.appendChild(btn);
  });
  renderPlanPhase(MK.PLAN[0], planContent);
  planDiv.appendChild(planTabs);
  planDiv.appendChild(planContent);
  content.appendChild(planDiv);

  // Leçons de grammaire
  const lesDiv = document.createElement('div');
  lesDiv.innerHTML = `<div style="font-size:13px;font-weight:bold;color:var(--muted);margin-bottom:10px;letter-spacing:1px">LEÇONS DE GRAMMAIRE</div>`;
  lessons.forEach(les=>{
    const locked = !les.free && !currentUser?.premium;
    const done = currentUser?.lessons_done?.includes(les.id);
    const card = document.createElement('div');
    card.style.cssText = `background:var(--card);border:1px solid ${done?'var(--g)':locked?'var(--bord)':'var(--bord)'};border-radius:14px;padding:14px;margin-bottom:10px;display:flex;align-items:center;gap:12px;cursor:pointer`;
    card.innerHTML = `
      <div style="font-size:28px">${les.icon}</div>
      <div style="flex:1">
        <div style="font-size:14px;font-weight:bold">${les.title}</div>
        <div style="font-size:11px;color:var(--muted)">+${les.xp} XP</div>
      </div>
      <div>
        ${done?'<span style="color:var(--g);font-size:18px">✓</span>':
          locked?'<span style="color:var(--r);font-size:14px">🔒</span>':
          '<span style="color:var(--g);font-size:13px">▶</span>'}
      </div>`;
    card.onclick = ()=>{
      if(locked){ toast('🔒 '+t('locked_msg')); return; }
      openLesson(les);
    };
    lesDiv.appendChild(card);
  });

  // Alphabet
  const alphaLang = MK.ALPHABET[lang] || MK.ALPHABET.en;
  const alphaDiv = document.createElement('div');
  alphaDiv.style.marginTop = '16px';
  alphaDiv.innerHTML = `<div style="font-size:13px;font-weight:bold;color:var(--muted);margin-bottom:10px;letter-spacing:1px">ALPHABET</div>
    <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:7px" id="learn-alpha-grid"></div>
    <div id="learn-alpha-detail" style="margin-top:10px;display:none"></div>`;

  content.appendChild(lesDiv);
  content.appendChild(alphaDiv);

  setTimeout(()=>{
    const ag = document.getElementById('learn-alpha-grid');
    if(!ag) return;
    alphaLang.forEach((item,i)=>{
      const d = document.createElement('div');
      d.style.cssText = 'background:var(--card);border:1px solid var(--bord);border-radius:10px;padding:10px 3px;text-align:center;cursor:pointer;transition:all .2s';
      d.innerHTML = `<div style="font-size:20px;font-weight:bold;color:var(--g)">${item.l}</div><div style="font-size:9px;color:var(--muted);font-family:monospace">${item.ph}</div>`;
      d.onclick = ()=>{
        speak(item.l, lang);
        const det = document.getElementById('learn-alpha-detail');
        det.style.display='flex';
        det.style.cssText='display:flex;align-items:center;gap:12px;background:var(--card);border:1px solid #00e5a033;border-radius:12px;padding:14px;margin-top:10px';
        det.innerHTML=`<span style="font-size:28px">${item.e}</span><div><div style="font-size:18px;font-weight:bold">${item.w}</div><div style="font-size:12px;color:var(--g);font-family:monospace">/${item.ph}/</div></div><button onclick="speak('${item.w}','${lang}')" style="margin-left:auto;background:#00e5a018;border:1px solid var(--g);color:var(--g);border-radius:8px;padding:8px 12px;cursor:pointer;font-size:13px">🔊</button>`;
      };
      ag.appendChild(d);
    });
  }, 100);
}

function renderPlanPhase(ph, container){
  container.style.cssText = `background:var(--card2);border:2px solid ${ph.color};border-radius:12px;padding:14px;margin-bottom:12px`;
  container.innerHTML = `
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px">
      <span style="background:${ph.color};color:#000;border-radius:6px;padding:3px 9px;font-size:10px;font-weight:bold">PHASE ${ph.phase}</span>
      <div><div style="font-size:15px;font-weight:bold">${ph.title}</div><div style="font-size:11px;color:var(--muted)">Jours ${ph.days}</div></div>
    </div>
    <ul style="list-style:none">
      ${ph.items.map(it=>`<li style="padding:5px 0;font-size:12px;border-bottom:1px solid #111;display:flex;gap:6px"><span style="color:${ph.color}">✓</span>${it}</li>`).join('')}
    </ul>`;
}

function openLesson(les){
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay';
  overlay.innerHTML = `
    <div class="modal" style="max-height:90vh;overflow-y:auto">
      <div class="modal-title">${les.icon} ${les.title}</div>
      <div style="background:var(--card);border-radius:10px;padding:14px;margin-bottom:14px;font-size:13px;color:var(--muted);line-height:1.6">${les.explanation}</div>
      <div style="font-size:13px;font-weight:bold;color:var(--g);margin-bottom:8px">${t('rules')}</div>
      <ul style="list-style:none;margin-bottom:16px">
        ${les.rules.map(r=>`<li style="padding:7px 0;border-bottom:1px solid var(--bord);font-size:13px;display:flex;gap:8px"><span style="color:var(--g)">▸</span>${r}</li>`).join('')}
      </ul>
      <div style="font-size:13px;font-weight:bold;color:var(--b);margin-bottom:8px">${t('examples')}</div>
      ${les.examples.map(ex=>`
        <div style="background:var(--card);border-radius:10px;padding:12px;margin-bottom:8px">
          <div style="font-size:14px;font-weight:bold;margin-bottom:4px">${ex.en} <button onclick="speak('${ex.en.replace(/'/g,"\\'")}','en')" style="background:none;border:none;cursor:pointer;font-size:14px">🔊</button></div>
          <div style="font-size:12px;color:var(--muted)">${ex.fr}</div>
        </div>`).join('')}
      <button class="btn btn-primary btn-full" style="margin-top:16px" onclick="finishLesson('${les.id}',${les.xp},this)">
        ${t('btn_finish')} (+${les.xp} XP)
      </button>
      <button class="btn btn-secondary btn-full" style="margin-top:8px" onclick="this.closest('.modal-overlay').remove()">Fermer</button>
    </div>`;
  document.body.appendChild(overlay);
}

function finishLesson(id, xp, btn){
  if(!currentUser.lessons_done.includes(id)){
    currentUser.lessons_done.push(id);
    currentUser.xp += xp;
    currentUser.daily_done = (currentUser.daily_done||0)+1;
    currentUser.coins += Math.floor(xp/5);
    saveUser();
    toast('🎉 '+t('well_done')+' '+xp+' XP !');
    refreshHomeUI();
  }
  btn.closest('.modal-overlay').remove();
  buildLearnTab();
}

// ── VOCAB TAB ─────────────────────────────────────────────────
let fcData = [], fcIndex = 0, fcKnew = 0, fcFlipped = false;

function buildVocabTab(){
  const lang = currentUser?.lang || 'en';
  const cats = MK.VOCAB[lang] || MK.VOCAB.en;
  const tabs = document.getElementById('vocab-cat-tabs');
  tabs.innerHTML = '';
  const catLabels = {daily:t('cat_daily'),numbers:t('cat_numbers'),colors:t('cat_colors'),science:t('cat_science')};
  let firstCat = null;
  Object.keys(cats).forEach((cat,i)=>{
    if(!firstCat) firstCat=cat;
    const btn = document.createElement('button');
    btn.className = 'btn btn-sm '+(i===0?'btn-outline':'btn-secondary');
    btn.style.whiteSpace='nowrap';
    btn.textContent = catLabels[cat]||cat;
    btn.onclick = ()=>{
      tabs.querySelectorAll('button').forEach(b=>b.className='btn btn-sm btn-secondary');
      btn.className='btn btn-sm btn-outline';
      startFlashcards(cats[cat]);
    };
    tabs.appendChild(btn);
  });
  if(firstCat) startFlashcards(cats[firstCat]);
}

function startFlashcards(data){
  fcData = [...data]; fcIndex=0; fcKnew=0; fcFlipped=false;
  renderFlashcard();
}

function renderFlashcard(){
  const area = document.getElementById('flashcard-area');
  const ctrl = document.getElementById('fc-controls');
  if(fcIndex >= fcData.length){
    const pct = Math.round(fcKnew/fcData.length*100);
    area.innerHTML = `
      <div style="text-align:center;padding:32px 0">
        <div style="font-size:48px;margin-bottom:12px">🎉</div>
        <div style="font-size:18px;font-weight:bold;margin-bottom:8px">${t('fc_done')}</div>
        <div style="font-size:14px;color:var(--muted)">${t('fc_score')} ${fcKnew}/${fcData.length} (${pct}%)</div>
        <div style="font-size:36px;margin:12px 0">${pct>=80?'⭐⭐⭐':pct>=50?'⭐⭐':'⭐'}</div>
      </div>`;
    ctrl.innerHTML = `<button class="btn btn-primary" onclick="startFlashcards(fcData)">🔄 Recommencer</button>`;
    addXP(fcKnew*3);
    return;
  }
  const w = fcData[fcIndex];
  area.innerHTML = `
    <div class="flashcard" onclick="flipFC()" id="fc-main">
      <div style="font-size:11px;color:var(--muted);margin-bottom:8px">${fcIndex+1} / ${fcData.length}</div>
      ${!fcFlipped?`
        <div style="font-size:36px;margin-bottom:8px">${w.e||'📖'}</div>
        <div class="fc-word">${w.w}</div>
        <div class="fc-sub">${t('tap_to_flip')}</div>`:`
        <div style="font-size:36px;margin-bottom:8px">${w.e||'📖'}</div>
        <div class="fc-translation">${w.t}</div>
        <div class="fc-example">"${w.ex}"</div>
        <button onclick="event.stopPropagation();speak('${w.w}','${currentUser?.lang||'en'}')" style="margin-top:8px;background:#00e5a018;border:1px solid var(--g);color:var(--g);border-radius:8px;padding:6px 14px;cursor:pointer;font-size:13px">🔊 Écouter</button>`}
    </div>`;
  ctrl.innerHTML = fcFlipped?`
    <button class="btn btn-danger btn-sm" onclick="fcAnswer(false)">${t('btn_unknown')}</button>
    <button class="btn btn-primary btn-sm" onclick="fcAnswer(true)">${t('btn_knew')}</button>`:'';
}

function flipFC(){
  if(!fcFlipped){ fcFlipped=true; renderFlashcard(); }
}
function fcAnswer(knew){
  if(knew) fcKnew++;
  fcIndex++; fcFlipped=false;
  renderFlashcard();
}

// ── QUIZ TAB ──────────────────────────────────────────────────
let quizData=[], quizIdx=0, quizScore=0, quizAnswered=false;

function buildQuizTab(){
  const lang = currentUser?.lang||'en';
  quizData = (MK.QUIZ[lang]||MK.QUIZ.en).sort(()=>Math.random()-.5);
  quizIdx=0; quizScore=0;
  renderQuizStart();
}

function renderQuizStart(){
  const area = document.getElementById('quiz-area');
  area.innerHTML = `
    <div style="text-align:center;padding:20px 0">
      <div style="font-size:56px;margin-bottom:12px">🎯</div>
      <div style="font-size:18px;font-weight:bold;margin-bottom:8px">${t('quiz_title')}</div>
      <div style="color:var(--muted);font-size:13px;margin-bottom:24px">${quizData.length} questions · XP à gagner</div>
      <button class="btn btn-primary" onclick="startQuiz()">${t('quiz_start')}</button>
    </div>`;
}

function startQuiz(){
  quizIdx=0; quizScore=0; quizAnswered=false;
  renderQuestion();
}

function renderQuestion(){
  const area = document.getElementById('quiz-area');
  if(quizIdx>=quizData.length){ renderQuizResult(); return; }
  const q = quizData[quizIdx];
  const pct = Math.round(quizIdx/quizData.length*100);
  area.innerHTML = `
    <div style="margin-bottom:14px">
      <div class="flex justify-between" style="margin-bottom:6px">
        <span style="font-size:12px;color:var(--muted)">${quizIdx+1} / ${quizData.length}</span>
        <span style="font-size:12px;color:var(--g)">${quizScore} pts</span>
      </div>
      <div class="progress-wrap"><div class="progress-bar" style="width:${pct}%"></div></div>
    </div>
    <div class="card" style="margin-bottom:14px;font-size:15px;font-weight:bold;line-height:1.5">${q.q}</div>
    <div id="quiz-opts">
      ${q.opts.map((opt,i)=>`<button class="quiz-option" onclick="answerQuiz(${i},${q.a},${q.pts})">${opt}</button>`).join('')}
    </div>
    <div id="quiz-feedback" style="display:none;text-align:center;padding:12px;border-radius:10px;margin-top:10px;font-weight:bold"></div>
    <button id="btn-quiz-next" class="btn btn-primary btn-full" style="display:none;margin-top:12px" onclick="nextQuestion()">
      ${quizIdx+1<quizData.length?t('btn_next'):'Voir résultats →'}
    </button>`;
}

function answerQuiz(chosen, correct, pts){
  if(quizAnswered) return;
  quizAnswered=true;
  const opts = document.querySelectorAll('.quiz-option');
  opts.forEach((btn,i)=>{
    btn.disabled=true;
    if(i===correct) btn.classList.add('correct');
    else if(i===chosen && chosen!==correct) btn.classList.add('wrong');
  });
  const fb = document.getElementById('quiz-feedback');
  fb.style.display='block';
  if(chosen===correct){
    quizScore+=pts;
    fb.style.background='#001a10';fb.style.color='var(--g)';fb.style.border='1px solid var(--g)';
    fb.textContent='✅ Correct ! +'+pts+' pts';
  } else {
    fb.style.background='#1a0010';fb.style.color='var(--r)';fb.style.border='1px solid var(--r)';
    fb.textContent='❌ '+quizData[quizIdx].opts[correct];
  }
  document.getElementById('btn-quiz-next').style.display='block';
}

function nextQuestion(){
  quizIdx++; quizAnswered=false;
  renderQuestion();
}

function renderQuizResult(){
  const total = quizData.reduce((s,q)=>s+q.pts,0);
  const pct = Math.round(quizScore/total*100);
  const msg = pct>=90?t('quiz_perfect'):pct>=60?t('quiz_good'):t('quiz_ok');
  const stars = pct>=90?'⭐⭐⭐':pct>=60?'⭐⭐':'⭐';
  addXP(Math.floor(quizScore/2));
  document.getElementById('quiz-area').innerHTML=`
    <div style="text-align:center;padding:24px 0">
      <div style="font-size:48px;margin-bottom:12px">${stars}</div>
      <div style="font-size:20px;font-weight:bold;margin-bottom:8px">${msg}</div>
      <div style="font-size:14px;color:var(--muted);margin-bottom:4px">${t('quiz_score')}</div>
      <div style="font-size:36px;font-weight:bold;color:var(--g)">${quizScore} / ${total}</div>
      <div style="font-size:13px;color:var(--muted);margin-bottom:24px">(${pct}%)</div>
      <button class="btn btn-primary" onclick="startQuiz()">${t('quiz_again')}</button>
    </div>`;
}

// ── PROFILE TAB ───────────────────────────────────────────────
function buildProfileTab(){
  if(!currentUser) return;
  const lang = MK.LANGUAGES[currentUser.lang]||MK.LANGUAGES.en;
  document.getElementById('profile-content').innerHTML=`
    <!-- Header -->
    <div style="text-align:center;padding:20px 0 16px">
      <div style="width:70px;height:70px;border-radius:50%;background:linear-gradient(135deg,var(--g),var(--b));display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:bold;color:#000;margin:0 auto 12px">${currentUser.name[0]}</div>
      <div style="font-size:20px;font-weight:bold">${currentUser.name}</div>
      <div style="font-size:12px;color:var(--muted)">${currentUser.email}</div>
      <span class="badge ${currentUser.premium?'badge-green':'badge-blue'}" style="margin-top:8px">${currentUser.premium?t('premium_badge'):'FREE'}</span>
      ${currentUser.role==='admin'?'<span class="badge badge-orange" style="margin-left:6px">ADMIN</span>':''}
    </div>

    <!-- Stats -->
    <div class="card mb-16">
      <div style="font-size:13px;font-weight:bold;color:var(--muted);margin-bottom:12px">${t('my_stats').toUpperCase()}</div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;text-align:center">
        <div><div style="font-size:22px;font-weight:bold;color:var(--g)">${currentUser.xp}</div><div style="font-size:10px;color:var(--muted)">${t('total_xp')}</div></div>
        <div><div style="font-size:22px;font-weight:bold;color:var(--o)">${currentUser.streak}🔥</div><div style="font-size:10px;color:var(--muted)">${t('days_streak')}</div></div>
        <div><div style="font-size:22px;font-weight:bold;color:var(--b)">${currentUser.lessons_done?.length||0}</div><div style="font-size:10px;color:var(--muted)">${t('lessons_done')}</div></div>
      </div>
    </div>

    <!-- Language -->
    <div class="card mb-16 flex items-center gap-12">
      <div style="font-size:32px">${lang.flag}</div>
      <div><div style="font-weight:bold">${lang.name}</div><div style="font-size:12px;color:var(--muted)">Langue apprise</div></div>
      <select class="input btn-sm" style="margin-left:auto;width:auto" onchange="changeLang(this.value)">
        ${Object.entries(MK.LANGUAGES).map(([k,v])=>`<option value="${k}" ${k===currentUser.lang?'selected':''}>${v.flag} ${v.name}</option>`).join('')}
      </select>
    </div>

    <!-- UI Language -->
    <div class="card mb-16">
      <div style="font-size:12px;font-weight:bold;color:var(--muted);margin-bottom:8px">LANGUE DE L'INTERFACE</div>
      <div style="display:flex;gap:8px">
        <button class="btn btn-sm ${uiLang==='fr'?'btn-primary':'btn-secondary'}" onclick="setUILang('fr');buildProfileTab()">🇫🇷 Français</button>
        <button class="btn btn-sm ${uiLang==='en'?'btn-primary':'btn-secondary'}" onclick="setUILang('en');buildProfileTab()">🇬🇧 English</button>
        <button class="btn btn-sm ${uiLang==='es'?'btn-primary':'btn-secondary'}" onclick="setUILang('es');buildProfileTab()">🇪🇸 Español</button>
      </div>
    </div>

    ${!currentUser.premium?`
    <!-- Premium -->
    <div class="card card-green mb-16">
      <div style="font-size:14px;font-weight:bold;margin-bottom:6px">⭐ ${t('premium_title')}</div>
      <div style="font-size:12px;color:var(--muted);margin-bottom:12px">${t('premium_desc')}</div>
      <div style="display:flex;gap:10px;margin-bottom:12px">
        <div style="flex:1;background:var(--card);border-radius:10px;padding:12px;text-align:center">
          <div style="font-size:18px;font-weight:bold;color:var(--g)">${appPrices.monthly} ${appPrices.currency}</div>
          <div style="font-size:11px;color:var(--muted)">/ mois</div>
        </div>
        <div style="flex:1;background:var(--card);border-radius:10px;padding:12px;text-align:center">
          <div style="font-size:18px;font-weight:bold;color:var(--b)">${appPrices.yearly} ${appPrices.currency}</div>
          <div style="font-size:11px;color:var(--muted)">/ an</div>
        </div>
      </div>
      <div style="font-size:11px;color:var(--muted);text-align:center">${t('contact_admin')}</div>
    </div>`:''}

    ${currentUser.role==='admin'?`<button class="btn btn-secondary btn-full mb-16" onclick="goAdmin()">⚙️ Panneau Admin</button>`:''}

    <button class="btn btn-danger btn-full" onclick="doLogout()">${t('btn_logout')}</button>`;
}

function changeLang(lang){
  currentUser.lang = lang;
  saveUser();
  buildLearnTab();
  buildVocabTab();
  buildQuizTab();
  buildProfileTab();
  refreshHomeUI();
  toast('✅ Langue changée !');
}

// ── ADMIN PANEL ───────────────────────────────────────────────
function buildAdminPanel(){
  const users = DB.get('users')||[];
  const premiumCount = users.filter(u=>u.premium).length;
  const prices = DB.get('prices')||MK.PRICES;

  document.getElementById('admin-content').innerHTML=`
    <div style="font-size:20px;font-weight:bold;margin-bottom:16px">⚙️ ${t('admin_title')}</div>

    <!-- Stats -->
    <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px;margin-bottom:16px;text-align:center">
      <div class="card"><div style="font-size:24px;font-weight:bold;color:var(--g)">${users.length}</div><div style="font-size:10px;color:var(--muted)">${t('total_users')}</div></div>
      <div class="card"><div style="font-size:24px;font-weight:bold;color:var(--o)">${premiumCount}</div><div style="font-size:10px;color:var(--muted)">${t('premium_users')}</div></div>
      <div class="card"><div style="font-size:24px;font-weight:bold;color:var(--b)">${premiumCount*prices.monthly}</div><div style="font-size:10px;color:var(--muted)">${prices.currency}</div></div>
    </div>

    <!-- Price Settings -->
    <div class="card mb-16">
      <div style="font-size:14px;font-weight:bold;margin-bottom:12px">💰 ${t('price_settings')}</div>
      <div class="input-group">
        <label class="input-label">${t('monthly_price')} (${prices.currency})</label>
        <input class="input" id="adm-monthly" type="number" value="${prices.monthly}"/>
      </div>
      <div class="input-group">
        <label class="input-label">${t('yearly_price')} (${prices.currency})</label>
        <input class="input" id="adm-yearly" type="number" value="${prices.yearly}"/>
      </div>
      <div class="input-group">
        <label class="input-label">${t('currency')}</label>
        <input class="input" id="adm-currency" type="text" value="${prices.currency}" placeholder="FCFA, EUR, USD..."/>
      </div>
      <button class="btn btn-primary btn-full" onclick="savePrices()">${t('btn_save')} ✓</button>
    </div>

    <!-- Free lessons count -->
    <div class="card mb-16">
      <div style="font-size:14px;font-weight:bold;margin-bottom:12px">🎁 Leçons gratuites</div>
      <div class="input-group">
        <label class="input-label">Nombre de leçons offertes</label>
        <input class="input" id="adm-free-lessons" type="number" value="${prices.free_lessons||3}" min="0" max="20"/>
      </div>
      <button class="btn btn-outline btn-full" onclick="saveFreeLessons()">Enregistrer</button>
    </div>

    <!-- Users list -->
    <div class="card">
      <div style="font-size:14px;font-weight:bold;margin-bottom:12px">👥 ${t('users_list')}</div>
      ${users.map(u=>`
        <div style="display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid var(--bord)">
          <div style="width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,var(--g),var(--b));display:flex;align-items:center;justify-content:center;font-weight:bold;color:#000;font-size:14px;flex-shrink:0">${u.name[0]}</div>
          <div style="flex:1;min-width:0">
            <div style="font-size:13px;font-weight:bold;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${u.name}</div>
            <div style="font-size:10px;color:var(--muted)">${u.email} · ${u.xp} XP</div>
          </div>
          <div style="display:flex;flex-direction:column;gap:4px;align-items:flex-end">
            <span class="badge ${u.premium?'badge-green':'badge-blue'}">${u.premium?'PREMIUM':'FREE'}</span>
            ${u.role!=='admin'?`<button class="btn btn-sm ${u.premium?'btn-danger':'btn-outline'}" onclick="togglePremium('${u.id}')">${u.premium?'Retirer':'Activer'}</button>`:'<span class="badge badge-orange">ADMIN</span>'}
          </div>
        </div>`).join('')}
    </div>`;
}

function savePrices(){
  const prices = {
    monthly: parseInt(document.getElementById('adm-monthly').value)||2000,
    yearly:  parseInt(document.getElementById('adm-yearly').value)||15000,
    currency: document.getElementById('adm-currency').value||'FCFA',
    free_lessons: appPrices.free_lessons||3,
  };
  appPrices = prices;
  DB.set('prices', prices);
  toast('✅ Prix mis à jour !');
  buildAdminPanel();
  buildProfileTab();
}

function saveFreeLessons(){
  appPrices.free_lessons = parseInt(document.getElementById('adm-free-lessons').value)||3;
  DB.set('prices', appPrices);
  toast('✅ Enregistré !');
}

function togglePremium(uid){
  const user = allUsers.find(u=>u.id===uid);
  if(!user) return;
  user.premium = !user.premium;
  DB.set('users', allUsers);
  if(currentUser && currentUser.id===uid) currentUser.premium=user.premium;
  toast(user.premium?'⭐ Premium activé !':'Premium retiré');
  buildAdminPanel();
}

// ── HELPERS ───────────────────────────────────────────────────
function speak(text, lang='en'){
  if(!('speechSynthesis' in window)) return;
  window.speechSynthesis.cancel();
  const u = new SpeechSynthesisUtterance(text);
  u.lang = MK.LANGUAGES[lang]?.target || 'en-US';
  u.rate = 0.85;
  window.speechSynthesis.speak(u);
}

function addXP(pts){
  if(!currentUser||pts<=0) return;
  currentUser.xp += pts;
  currentUser.coins += Math.floor(pts/10);
  saveUser();
  refreshHomeUI();
  toast('✨ +'+pts+' XP !');
}

function saveUser(){
  const idx = allUsers.findIndex(u=>u.id===currentUser.id);
  if(idx>=0) allUsers[idx] = currentUser;
  DB.set('users', allUsers);
  DB.set('current_user_data', currentUser);
}

function toast(msg){
  const existing = document.querySelector('.toast');
  if(existing) existing.remove();
  const el = document.createElement('div');
  el.className='toast';
  el.textContent=msg;
  document.body.appendChild(el);
  setTimeout(()=>el.remove(), 2800);
}

// ── PWA INSTALL ───────────────────────────────────────────────
let deferredPrompt = null;
window.addEventListener('beforeinstallprompt', e=>{
  e.preventDefault(); deferredPrompt=e;
  document.getElementById('install-bar').classList.remove('hidden');
});
document.getElementById('btn-install').addEventListener('click',()=>{
  if(!deferredPrompt) return;
  deferredPrompt.prompt();
  deferredPrompt.userChoice.then(()=>{
    deferredPrompt=null;
    document.getElementById('install-bar').classList.add('hidden');
  });
});
window.addEventListener('appinstalled',()=>{
  document.getElementById('install-bar').classList.add('hidden');
});
if('serviceWorker' in navigator){
  navigator.serviceWorker.register('./sw.js').catch(()=>{});
}

// ── BOOT ──────────────────────────────────────────────────────
function boot(){
  ensureAdmin();
  applyTranslations();
  // Vérifier session existante
  const savedId = DB.get('current_user');
  if(savedId){
    const user = allUsers.find(u=>u.id===savedId);
    if(user){ currentUser=user; setTimeout(()=>{ showScreen('s-app'); afterLogin(); },1200); return; }
  }
  setTimeout(()=>showScreen('s-auth'), 1200);
}
boot();
