// ============================================================
// MK ACADEMY — DATA.JS
// Tout le contenu d'apprentissage + configuration
// ============================================================

const MK = {

  // ── ADMIN CONFIG (Marius KPOTIN) ──────────────────────────
  ADMIN_EMAIL: "mariuskpotin@gmail.com", // Change ton email ici
  APP_NAME: "MK Academy",
  VERSION: "1.0.0",

  // ── PRIX (fixés par l'admin) ──────────────────────────────
  PRICES: {
    monthly: 2000,   // FCFA ou ta monnaie
    yearly:  15000,
    currency: "FCFA",
    free_lessons: 3, // leçons gratuites avant paiement
  },

  // ── LANGUES DISPONIBLES ───────────────────────────────────
  LANGUAGES: {
    en: { name: "Anglais",    flag: "🇬🇧", target: "en-US" },
    es: { name: "Espagnol",   flag: "🇪🇸", target: "es-ES" },
    fr: { name: "Français",   flag: "🇫🇷", target: "fr-FR" },
    de: { name: "Allemand",   flag: "🇩🇪", target: "de-DE" },
    zh: { name: "Chinois",    flag: "🇨🇳", target: "zh-CN" },
  },

  // ── MODULES D'APPRENTISSAGE ───────────────────────────────
  MODULES: [
    { id:"alphabet",  icon:"🔤", color:"#00e5a0", free:true  },
    { id:"basics",    icon:"💬", color:"#4f8ef7", free:true  },
    { id:"grammar",   icon:"✏️",  color:"#f7a44f", free:false },
    { id:"vocab",     icon:"📚", color:"#c47aff", free:false },
    { id:"listening", icon:"🎧", color:"#ff5a7a", free:false },
    { id:"science",   icon:"🔬", color:"#00d4ff", free:false },
  ],

  // ── ALPHABET ──────────────────────────────────────────────
  ALPHABET: {
    en: [
      {l:"A",ph:"eï",w:"Apple",e:"🍎"},{l:"B",ph:"bi",w:"Ball",e:"⚽"},
      {l:"C",ph:"si",w:"Cat",e:"🐱"},{l:"D",ph:"di",w:"Dog",e:"🐶"},
      {l:"E",ph:"i",w:"Egg",e:"🥚"},{l:"F",ph:"èf",w:"Fish",e:"🐟"},
      {l:"G",ph:"dji",w:"Grapes",e:"🍇"},{l:"H",ph:"eïtch",w:"House",e:"🏠"},
      {l:"I",ph:"aï",w:"Ice",e:"🧊"},{l:"J",ph:"djeï",w:"Jump",e:"🦘"},
      {l:"K",ph:"keï",w:"King",e:"👑"},{l:"L",ph:"èl",w:"Lion",e:"🦁"},
      {l:"M",ph:"èm",w:"Moon",e:"🌙"},{l:"N",ph:"èn",w:"Night",e:"🌃"},
      {l:"O",ph:"o",w:"Orange",e:"🍊"},{l:"P",ph:"pi",w:"Pen",e:"✏️"},
      {l:"Q",ph:"kiou",w:"Queen",e:"👸"},{l:"R",ph:"ar",w:"Rain",e:"🌧️"},
      {l:"S",ph:"èss",w:"Sun",e:"☀️"},{l:"T",ph:"ti",w:"Tree",e:"🌳"},
      {l:"U",ph:"iou",w:"Umbrella",e:"☂️"},{l:"V",ph:"vi",w:"Volcano",e:"🌋"},
      {l:"W",ph:"deubeliou",w:"Water",e:"💧"},{l:"X",ph:"èks",w:"X-ray",e:"🔬"},
      {l:"Y",ph:"ouaï",w:"Yellow",e:"🌻"},{l:"Z",ph:"zi",w:"Zebra",e:"🦓"},
    ],
    es: [
      {l:"A",ph:"a",w:"Agua",e:"💧"},{l:"B",ph:"be",w:"Boca",e:"👄"},
      {l:"C",ph:"se",w:"Casa",e:"🏠"},{l:"D",ph:"de",w:"Dato",e:"📊"},
      {l:"E",ph:"e",w:"Estrella",e:"⭐"},{l:"F",ph:"efe",w:"Flor",e:"🌸"},
      {l:"G",ph:"gue",w:"Gato",e:"🐱"},{l:"H",ph:"ache",w:"Hoja",e:"🍃"},
      {l:"I",ph:"i",w:"Isla",e:"🏝️"},{l:"J",ph:"jota",w:"Juego",e:"🎮"},
      {l:"K",ph:"ka",w:"Kilo",e:"⚖️"},{l:"L",ph:"ele",w:"Luna",e:"🌙"},
      {l:"M",ph:"eme",w:"Mar",e:"🌊"},{l:"N",ph:"ene",w:"Noche",e:"🌃"},
      {l:"O",ph:"o",w:"Oso",e:"🐻"},{l:"P",ph:"pe",w:"Pan",e:"🍞"},
      {l:"Q",ph:"cu",w:"Queso",e:"🧀"},{l:"R",ph:"erre",w:"Rosa",e:"🌹"},
      {l:"S",ph:"ese",w:"Sol",e:"☀️"},{l:"T",ph:"te",w:"Taza",e:"☕"},
      {l:"U",ph:"u",w:"Uva",e:"🍇"},{l:"V",ph:"uve",w:"Vaca",e:"🐄"},
      {l:"W",ph:"doble uve",w:"Web",e:"🌐"},{l:"X",ph:"equis",w:"Xilófono",e:"🎵"},
      {l:"Y",ph:"ye",w:"Yate",e:"⛵"},{l:"Z",ph:"zeta",w:"Zapato",e:"👟"},
    ],
  },

  // ── VOCABULAIRE PAR LANGUE ET CATÉGORIE ───────────────────
  VOCAB: {
    en: {
      daily: [
        {w:"Hello",t:"Bonjour",ex:"Hello, how are you?",e:"👋"},
        {w:"Thank you",t:"Merci",ex:"Thank you very much!",e:"🙏"},
        {w:"Please",t:"S'il vous plaît",ex:"Can I have water, please?",e:"🥤"},
        {w:"Sorry",t:"Désolé",ex:"Sorry, I was late.",e:"😔"},
        {w:"Yes",t:"Oui",ex:"Yes, I agree.",e:"✅"},
        {w:"No",t:"Non",ex:"No, thank you.",e:"❌"},
        {w:"Water",t:"Eau",ex:"I need water.",e:"💧"},
        {w:"Food",t:"Nourriture",ex:"The food is delicious.",e:"🍽️"},
        {w:"Help",t:"Aide",ex:"I need help.",e:"🆘"},
        {w:"Friend",t:"Ami",ex:"She is my best friend.",e:"👫"},
        {w:"Family",t:"Famille",ex:"I love my family.",e:"👨‍👩‍👧"},
        {w:"Home",t:"Maison",ex:"I am going home.",e:"🏠"},
      ],
      numbers: [
        {w:"One",t:"Un",ex:"I have one cat.",e:"1️⃣"},
        {w:"Two",t:"Deux",ex:"Two plus two is four.",e:"2️⃣"},
        {w:"Three",t:"Trois",ex:"Three days later.",e:"3️⃣"},
        {w:"Four",t:"Quatre",ex:"Four seasons.",e:"4️⃣"},
        {w:"Five",t:"Cinq",ex:"Five fingers.",e:"5️⃣"},
        {w:"Ten",t:"Dix",ex:"Ten minutes.",e:"🔟"},
        {w:"Hundred",t:"Cent",ex:"One hundred students.",e:"💯"},
        {w:"Thousand",t:"Mille",ex:"A thousand stars.",e:"⭐"},
      ],
      colors: [
        {w:"Red",t:"Rouge",ex:"The apple is red.",e:"🔴"},
        {w:"Blue",t:"Bleu",ex:"The sky is blue.",e:"🔵"},
        {w:"Green",t:"Vert",ex:"Grass is green.",e:"🟢"},
        {w:"Yellow",t:"Jaune",ex:"The sun is yellow.",e:"🟡"},
        {w:"Black",t:"Noir",ex:"The night is black.",e:"⚫"},
        {w:"White",t:"Blanc",ex:"Snow is white.",e:"⚪"},
        {w:"Orange",t:"Orange",ex:"Oranges are orange.",e:"🟠"},
        {w:"Purple",t:"Violet",ex:"Lavender is purple.",e:"🟣"},
      ],
      science: [
        {w:"Algorithm",t:"Algorithme",ex:"Implement the algorithm.",e:"⚙️"},
        {w:"Derivative",t:"Dérivée",ex:"The derivative of x² is 2x.",e:"📐"},
        {w:"Matrix",t:"Matrice",ex:"Multiply the matrix.",e:"🔢"},
        {w:"Function",t:"Fonction",ex:"Define the function f(x).",e:"📊"},
        {w:"Vector",t:"Vecteur",ex:"The vector has magnitude 5.",e:"➡️"},
        {w:"Integral",t:"Intégrale",ex:"Compute the integral.",e:"∫"},
        {w:"Recursion",t:"Récursivité",ex:"Use recursion to solve this.",e:"🔄"},
        {w:"Complexity",t:"Complexité",ex:"O(n log n) complexity.",e:"📈"},
        {w:"Database",t:"Base de données",ex:"Query the database.",e:"🗄️"},
        {w:"Network",t:"Réseau",ex:"Configure the network.",e:"🌐"},
        {w:"Theorem",t:"Théorème",ex:"Prove the theorem.",e:"📝"},
        {w:"Probability",t:"Probabilité",ex:"The probability is 0.75.",e:"🎲"},
      ],
    },
    es: {
      daily: [
        {w:"Hola",t:"Bonjour",ex:"Hola, ¿cómo estás?",e:"👋"},
        {w:"Gracias",t:"Merci",ex:"¡Muchas gracias!",e:"🙏"},
        {w:"Por favor",t:"S'il vous plaît",ex:"Agua, por favor.",e:"🥤"},
        {w:"Lo siento",t:"Désolé",ex:"Lo siento mucho.",e:"😔"},
        {w:"Sí",t:"Oui",ex:"Sí, estoy de acuerdo.",e:"✅"},
        {w:"No",t:"Non",ex:"No, gracias.",e:"❌"},
        {w:"Agua",t:"Eau",ex:"Necesito agua.",e:"💧"},
        {w:"Comida",t:"Nourriture",ex:"La comida es deliciosa.",e:"🍽️"},
        {w:"Ayuda",t:"Aide",ex:"Necesito ayuda.",e:"🆘"},
        {w:"Amigo",t:"Ami",ex:"Ella es mi mejor amiga.",e:"👫"},
      ],
      numbers: [
        {w:"Uno",t:"Un",ex:"Tengo un gato.",e:"1️⃣"},
        {w:"Dos",t:"Deux",ex:"Dos más dos son cuatro.",e:"2️⃣"},
        {w:"Tres",t:"Trois",ex:"Tres días después.",e:"3️⃣"},
        {w:"Cuatro",t:"Quatre",ex:"Cuatro estaciones.",e:"4️⃣"},
        {w:"Cinco",t:"Cinq",ex:"Cinco dedos.",e:"5️⃣"},
        {w:"Diez",t:"Dix",ex:"Diez minutos.",e:"🔟"},
      ],
      colors: [
        {w:"Rojo",t:"Rouge",ex:"La manzana es roja.",e:"🔴"},
        {w:"Azul",t:"Bleu",ex:"El cielo es azul.",e:"🔵"},
        {w:"Verde",t:"Vert",ex:"La hierba es verde.",e:"🟢"},
        {w:"Amarillo",t:"Jaune",ex:"El sol es amarillo.",e:"🟡"},
        {w:"Negro",t:"Noir",ex:"La noche es negra.",e:"⚫"},
        {w:"Blanco",t:"Blanc",ex:"La nieve es blanca.",e:"⚪"},
      ],
      science: [
        {w:"Algoritmo",t:"Algorithme",ex:"Implementa el algoritmo.",e:"⚙️"},
        {w:"Función",t:"Fonction",ex:"Define la función f(x).",e:"📊"},
        {w:"Vector",t:"Vecteur",ex:"El vector tiene magnitud 5.",e:"➡️"},
        {w:"Matriz",t:"Matrice",ex:"Multiplica la matriz.",e:"🔢"},
        {w:"Probabilidad",t:"Probabilité",ex:"La probabilidad es 0.75.",e:"🎲"},
        {w:"Red",t:"Réseau",ex:"Configura la red.",e:"🌐"},
      ],
    },
  },

  // ── QUIZ PAR LANGUE ───────────────────────────────────────
  QUIZ: {
    en: [
      {q:"How do you say 'Bonjour' in English?", opts:["Hello","Goodbye","Sorry","Please"], a:0, pts:10},
      {q:"What is the plural of 'child'?", opts:["childs","children","childrens","child"], a:1, pts:10},
      {q:"Choose the correct sentence:", opts:["I am go to school","I goes to school","I go to school","I going school"], a:2, pts:15},
      {q:"'Heavy rain' means:", opts:["Pluie légère","Pluie froide","Forte pluie","Pluie chaude"], a:2, pts:10},
      {q:"The derivative of x³ is:", opts:["3x","3x²","x²","2x³"], a:1, pts:20},
      {q:"What is 'algorithme' in English?", opts:["Algebra","Algorithm","Arithmetic","Alignment"], a:1, pts:10},
      {q:"'I have been studying' is in:", opts:["Present simple","Past simple","Present perfect","Future"], a:2, pts:15},
      {q:"Which word means 'probabilité'?", opts:["Possibility","Probability","Proficiency","Proximity"], a:1, pts:10},
      {q:"'Make a mistake' — which is WRONG?", opts:["Make an error","Do a mistake","Commit an error","Make a blunder"], a:1, pts:15},
      {q:"O(n log n) is the complexity of:", opts:["Bubble sort","Quick sort","Linear search","Binary search"], a:1, pts:20},
    ],
    es: [
      {q:"Comment dit-on 'Bonjour' en espagnol?", opts:["Adios","Hola","Gracias","Buenos"], a:1, pts:10},
      {q:"¿Cómo se dice 'merci' en español?", opts:["Por favor","Perdón","Gracias","De nada"], a:2, pts:10},
      {q:"'Agua' significa:", opts:["Feu","Terre","Air","Eau"], a:3, pts:10},
      {q:"El plural de 'ciudad' es:", opts:["ciudades","ciudads","ciudade","ciudad"], a:0, pts:15},
      {q:"'Probabilidad' en français c'est:", opts:["Possibilité","Probabilité","Profondeur","Proximité"], a:1, pts:10},
    ],
  },

  // ── LEÇONS DE GRAMMAIRE ───────────────────────────────────
  LESSONS: {
    en: [
      {
        id:"present_simple", title:"Present Simple", icon:"⏱️", xp:30, free:true,
        explanation:"Le présent simple exprime des habitudes, des vérités générales.",
        rules:[
          "I/You/We/They → verbe de base : I work",
          "He/She/It → verbe + S : She works",
          "Négation : don't / doesn't + verbe",
          "Question : Do/Does + sujet + verbe ?",
        ],
        examples:[
          {en:"I go to school every day.", fr:"Je vais à l'école tous les jours."},
          {en:"She doesn't like coffee.", fr:"Elle n'aime pas le café."},
          {en:"Do you speak English?", fr:"Parlez-vous anglais ?"},
          {en:"The sun rises in the east.", fr:"Le soleil se lève à l'est."},
        ],
      },
      {
        id:"present_cont", title:"Present Continuous", icon:"▶️", xp:30, free:true,
        explanation:"Le présent continu exprime une action en cours maintenant.",
        rules:[
          "Structure : am/is/are + verbe-ING",
          "I am working right now.",
          "She is not sleeping.",
          "Are they coming?",
        ],
        examples:[
          {en:"I am studying English.", fr:"Je suis en train d'étudier l'anglais."},
          {en:"He is not working today.", fr:"Il ne travaille pas aujourd'hui."},
          {en:"What are you doing?", fr:"Qu'est-ce que tu fais ?"},
          {en:"They are playing football.", fr:"Ils jouent au football."},
        ],
      },
      {
        id:"past_simple", title:"Past Simple", icon:"⏪", xp:40, free:false,
        explanation:"Le passé simple exprime une action terminée dans le passé.",
        rules:[
          "Verbes réguliers : + ED → worked, played",
          "Verbes irréguliers : go→went, have→had, be→was/were",
          "Négation : didn't + verbe base",
          "Question : Did + sujet + verbe base ?",
        ],
        examples:[
          {en:"I went to Paris last year.", fr:"Je suis allé à Paris l'année dernière."},
          {en:"She didn't come to class.", fr:"Elle n'est pas venue en classe."},
          {en:"Did you see the movie?", fr:"As-tu vu le film ?"},
          {en:"We had a great time.", fr:"Nous avons passé un bon moment."},
        ],
      },
      {
        id:"modals", title:"Modaux (can/must/should)", icon:"🔧", xp:35, free:false,
        explanation:"Les modaux expriment la capacité, l'obligation ou le conseil.",
        rules:[
          "CAN : capacité → I can swim.",
          "MUST : obligation forte → You must study.",
          "SHOULD : conseil → You should rest.",
          "MIGHT : possibilité → It might rain.",
        ],
        examples:[
          {en:"I can speak three languages.", fr:"Je peux parler trois langues."},
          {en:"You must wear a seatbelt.", fr:"Tu dois porter une ceinture."},
          {en:"You should sleep early.", fr:"Tu devrais dormir tôt."},
          {en:"It might snow tomorrow.", fr:"Il pourrait neiger demain."},
        ],
      },
      {
        id:"conditionals", title:"Conditionnels", icon:"🔀", xp:50, free:false,
        explanation:"Les conditionnels expriment des situations hypothétiques.",
        rules:[
          "0 : If + present, present → habitude",
          "1 : If + present, will → possible futur",
          "2 : If + past, would → hypothétique",
          "3 : If + had + pp, would have → passé irréel",
        ],
        examples:[
          {en:"If it rains, I stay home.", fr:"S'il pleut, je reste à la maison."},
          {en:"If I study, I will pass.", fr:"Si j'étudie, je passerai."},
          {en:"If I were rich, I would travel.", fr:"Si j'étais riche, je voyagerais."},
          {en:"If I had studied, I would have passed.", fr:"Si j'avais étudié, j'aurais réussi."},
        ],
      },
    ],
    es: [
      {
        id:"presente", title:"Presente Indicativo", icon:"⏱️", xp:30, free:true,
        explanation:"Le présent de l'indicatif en espagnol.",
        rules:[
          "Verbes en -AR : hablo, hablas, habla...",
          "Verbes en -ER : como, comes, come...",
          "Verbes en -IR : vivo, vives, vive...",
          "Irréguliers : ser→soy, estar→estoy, ir→voy",
        ],
        examples:[
          {en:"Yo hablo español.", fr:"Je parle espagnol."},
          {en:"Ella come mucho.", fr:"Elle mange beaucoup."},
          {en:"¿Dónde vives?", fr:"Où habites-tu ?"},
          {en:"Soy estudiante.", fr:"Je suis étudiant."},
        ],
      },
      {
        id:"ser_estar", title:"Ser vs Estar", icon:"🔄", xp:40, free:true,
        explanation:"Deux verbes pour 'être' en espagnol.",
        rules:[
          "SER : identité, origine, caractère permanent",
          "ESTAR : état temporaire, position, émotion",
          "Soy María (identité) vs Estoy cansada (état)",
          "Es médico (profession) vs Está en casa (lieu)",
        ],
        examples:[
          {en:"Soy de África.", fr:"Je suis d'Afrique."},
          {en:"Estoy feliz hoy.", fr:"Je suis heureux aujourd'hui."},
          {en:"El libro es azul.", fr:"Le livre est bleu."},
          {en:"Está en la mesa.", fr:"Il est sur la table."},
        ],
      },
    ],
  },

  // ── PLAN 60 JOURS ─────────────────────────────────────────
  PLAN: [
    {phase:1,title:"Fondations",days:"1–15",color:"#00e5a0",icon:"🌱",
     items:["500 mots fréquents (Anki)","Présent simple vs continu","Passé simple","Futur : will/going to","Questions et négations","Modaux","Conditionnels 0,1,2","Passif et discours indirect","Écoute BBC 6 Min English","Shadowing quotidien"]},
    {phase:2,title:"Construction",days:"16–35",color:"#4f8ef7",icon:"🏗️",
     items:["500 mots thématiques","Collocations naturelles","Lecture BBC News","Nouvelles courtes","Monologues 2 min","Tandem/HelloTalk","Débats simples","Journal 100 mots/jour","Opinions structurées","Écoute vitesse normale"]},
    {phase:3,title:"Immersion",days:"36–50",color:"#f7a44f",icon:"🌍",
     items:["Téléphone en anglais","Podcasts fond sonore","Penser en anglais","Séries TV VO","Films sans sous-titres","The Daily NYT","Reddit/Twitter EN","10 idiomes/semaine","Stand-up comedy","Écoute 1.25x"]},
    {phase:4,title:"Consolidation",days:"51–60",color:"#c47aff",icon:"🔬",
     items:["Monologue 5 min","Entretien simulé","Rédaction 400 mots","Test oral IA","5 min sans pause","80%+ podcast compris","BBC sans dico","200 mots en 10 min","Bilan 60 jours","Objectifs suivants"]},
  ],
};
