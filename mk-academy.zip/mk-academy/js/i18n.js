// ============================================================
// MK ACADEMY — I18N.JS  (Traductions interface)
// ============================================================

const I18N = {
  fr: {
    // AUTH
    login:"Connexion", register:"Créer un compte",
    email:"EMAIL", password:"MOT DE PASSE", fullname:"NOM COMPLET",
    lang_choice:"LANGUE À APPRENDRE",
    no_account:"Pas de compte ? ", signup:"S'inscrire",
    back_login:"← Retour connexion",
    btn_login:"Se connecter →", btn_register:"Créer mon compte →",
    auth_subtitle:"Apprends les langues comme un natif",
    // NAV
    nav_home:"Accueil", nav_learn:"Leçons", nav_vocab:"Vocab",
    nav_quiz:"Quiz", nav_profile:"Profil",
    // HOME
    welcome_back:"Bienvenue,", streak:"SÉRIE DU JOUR", xp:"POINTS XP",
    daily_goal:"Objectif du jour", learning:"J'APPRENDS",
    level:"Niveau :", modules_title:"Modules",
    btn_continue:"Continuer →",
    // MODULES
    mod_alphabet:"Alphabet", mod_basics:"Bases", mod_grammar:"Grammaire",
    mod_vocab:"Vocabulaire", mod_listening:"Écoute", mod_science:"Sciences",
    // LEARN
    learn_title:"Apprendre", lesson_free:"GRATUIT", lesson_locked:"🔒 PREMIUM",
    btn_start:"Commencer", btn_next:"Suivant →", btn_finish:"Terminer ✓",
    rules:"Règles", examples:"Exemples", well_done:"Bravo ! +",
    // VOCAB
    vocab_title:"Vocabulaire", vocab_sub:"Flashcards interactives",
    cat_daily:"Quotidien", cat_numbers:"Nombres", cat_colors:"Couleurs", cat_science:"Sciences",
    tap_to_flip:"Appuie pour voir", btn_knew:"✓ Je savais", btn_unknown:"✗ À revoir",
    fc_done:"Série terminée ! 🎉", fc_score:"Score :",
    // QUIZ
    quiz_title:"Quiz", quiz_start:"Commencer le quiz →",
    quiz_score:"Score final :", quiz_again:"Rejouer", quiz_perfect:"Parfait ! 🏆",
    quiz_good:"Très bien ! 🌟", quiz_ok:"Continue ! 💪",
    // PROFILE
    profile_title:"Mon Profil", my_stats:"Mes statistiques",
    total_xp:"XP Total", days_streak:"Jours de série", lessons_done:"Leçons terminées",
    my_plan:"Mon Plan 60 Jours", premium_title:"Passer Premium",
    premium_desc:"Débloquez toutes les leçons et fonctionnalités !",
    btn_premium:"Devenir Premium",
    btn_logout:"Se déconnecter",
    // ADMIN
    admin_title:"Panneau Admin", total_users:"Utilisateurs",
    premium_users:"Abonnés Premium", revenue:"Revenus",
    price_settings:"Paramètres Prix", monthly_price:"Prix mensuel",
    yearly_price:"Prix annuel", currency:"Devise",
    btn_save:"Enregistrer", users_list:"Liste des utilisateurs",
    plan_title:"Plan 60 Jours",
    // MISC
    free_badge:"GRATUIT", premium_badge:"PREMIUM",
    locked_msg:"Cette leçon est réservée aux membres Premium.",
    contact_admin:"Contactez l'administrateur pour vous abonner.",
    xp_earned:"XP gagnés !",
  },
  en: {
    login:"Login", register:"Create Account",
    email:"EMAIL", password:"PASSWORD", fullname:"FULL NAME",
    lang_choice:"LANGUAGE TO LEARN",
    no_account:"No account? ", signup:"Sign up",
    back_login:"← Back to login",
    btn_login:"Login →", btn_register:"Create my account →",
    auth_subtitle:"Learn languages like a native",
    nav_home:"Home", nav_learn:"Lessons", nav_vocab:"Vocab",
    nav_quiz:"Quiz", nav_profile:"Profile",
    welcome_back:"Welcome,", streak:"DAY STREAK", xp:"XP POINTS",
    daily_goal:"Daily goal", learning:"I'M LEARNING",
    level:"Level:", modules_title:"Modules",
    btn_continue:"Continue →",
    mod_alphabet:"Alphabet", mod_basics:"Basics", mod_grammar:"Grammar",
    mod_vocab:"Vocabulary", mod_listening:"Listening", mod_science:"Science",
    learn_title:"Learn", lesson_free:"FREE", lesson_locked:"🔒 PREMIUM",
    btn_start:"Start", btn_next:"Next →", btn_finish:"Finish ✓",
    rules:"Rules", examples:"Examples", well_done:"Well done! +",
    vocab_title:"Vocabulary", vocab_sub:"Interactive flashcards",
    cat_daily:"Daily", cat_numbers:"Numbers", cat_colors:"Colors", cat_science:"Science",
    tap_to_flip:"Tap to see", btn_knew:"✓ I knew it", btn_unknown:"✗ Review",
    fc_done:"Series done! 🎉", fc_score:"Score:",
    quiz_title:"Quiz", quiz_start:"Start quiz →",
    quiz_score:"Final score:", quiz_again:"Play again", quiz_perfect:"Perfect! 🏆",
    quiz_good:"Great! 🌟", quiz_ok:"Keep going! 💪",
    profile_title:"My Profile", my_stats:"My statistics",
    total_xp:"Total XP", days_streak:"Day streak", lessons_done:"Lessons done",
    my_plan:"My 60-Day Plan", premium_title:"Go Premium",
    premium_desc:"Unlock all lessons and features!",
    btn_premium:"Go Premium",
    btn_logout:"Log out",
    admin_title:"Admin Panel", total_users:"Users",
    premium_users:"Premium members", revenue:"Revenue",
    price_settings:"Price Settings", monthly_price:"Monthly price",
    yearly_price:"Yearly price", currency:"Currency",
    btn_save:"Save", users_list:"Users list",
    plan_title:"60-Day Plan",
    free_badge:"FREE", premium_badge:"PREMIUM",
    locked_msg:"This lesson is for Premium members only.",
    contact_admin:"Contact the administrator to subscribe.",
    xp_earned:"XP earned!",
  },
  es: {
    login:"Iniciar sesión", register:"Crear cuenta",
    email:"CORREO", password:"CONTRASEÑA", fullname:"NOMBRE COMPLETO",
    lang_choice:"IDIOMA A APRENDER",
    no_account:"¿Sin cuenta? ", signup:"Registrarse",
    back_login:"← Volver al login",
    btn_login:"Entrar →", btn_register:"Crear mi cuenta →",
    auth_subtitle:"Aprende idiomas como un nativo",
    nav_home:"Inicio", nav_learn:"Lecciones", nav_vocab:"Vocab",
    nav_quiz:"Quiz", nav_profile:"Perfil",
    welcome_back:"Bienvenido,", streak:"RACHA DEL DÍA", xp:"PUNTOS XP",
    daily_goal:"Objetivo del día", learning:"APRENDO",
    level:"Nivel:", modules_title:"Módulos",
    btn_continue:"Continuar →",
    mod_alphabet:"Alfabeto", mod_basics:"Básico", mod_grammar:"Gramática",
    mod_vocab:"Vocabulario", mod_listening:"Escucha", mod_science:"Ciencias",
    learn_title:"Aprender", lesson_free:"GRATIS", lesson_locked:"🔒 PREMIUM",
    btn_start:"Empezar", btn_next:"Siguiente →", btn_finish:"Terminar ✓",
    rules:"Reglas", examples:"Ejemplos", well_done:"¡Muy bien! +",
    vocab_title:"Vocabulario", vocab_sub:"Tarjetas interactivas",
    cat_daily:"Cotidiano", cat_numbers:"Números", cat_colors:"Colores", cat_science:"Ciencias",
    tap_to_flip:"Toca para ver", btn_knew:"✓ Lo sabía", btn_unknown:"✗ Repasar",
    fc_done:"¡Serie completa! 🎉", fc_score:"Puntuación:",
    quiz_title:"Quiz", quiz_start:"Empezar quiz →",
    quiz_score:"Puntuación final:", quiz_again:"Jugar de nuevo", quiz_perfect:"¡Perfecto! 🏆",
    quiz_good:"¡Muy bien! 🌟", quiz_ok:"¡Sigue adelante! 💪",
    profile_title:"Mi Perfil", my_stats:"Mis estadísticas",
    total_xp:"XP Total", days_streak:"Días de racha", lessons_done:"Lecciones hechas",
    my_plan:"Mi Plan 60 Días", premium_title:"Ir Premium",
    premium_desc:"¡Desbloquea todas las lecciones!",
    btn_premium:"Ir Premium",
    btn_logout:"Cerrar sesión",
    admin_title:"Panel Admin", total_users:"Usuarios",
    premium_users:"Miembros Premium", revenue:"Ingresos",
    price_settings:"Ajustes de Precio", monthly_price:"Precio mensual",
    yearly_price:"Precio anual", currency:"Moneda",
    btn_save:"Guardar", users_list:"Lista de usuarios",
    plan_title:"Plan 60 Días",
    free_badge:"GRATIS", premium_badge:"PREMIUM",
    locked_msg:"Esta lección es solo para miembros Premium.",
    contact_admin:"Contacta al administrador para suscribirte.",
    xp_earned:"¡XP ganados!",
  },
};

let uiLang = localStorage.getItem('mk_ui_lang') || 'fr';
function t(key){ return (I18N[uiLang]||I18N.fr)[key] || key; }
function setUILang(lang){
  uiLang = lang;
  localStorage.setItem('mk_ui_lang', lang);
  applyTranslations();
}
function applyTranslations(){
  // Auth
  document.getElementById('auth-lang-subtitle').textContent = t('auth_subtitle');
  document.getElementById('lbl-login').textContent = t('login');
  document.getElementById('lbl-email').textContent = t('email');
  document.getElementById('lbl-pass').textContent = t('password');
  document.getElementById('btn-do-login').textContent = t('btn_login');
  document.getElementById('lbl-noaccount').textContent = t('no_account');
  document.getElementById('btn-to-register').textContent = t('signup');
  document.getElementById('lbl-register').textContent = t('register');
  document.getElementById('lbl-lang-choice').textContent = t('lang_choice');
  document.getElementById('btn-do-register').textContent = t('btn_register');
  document.getElementById('btn-to-login').textContent = t('back_login');
  // Nav
  document.getElementById('bnav-lbl-home').textContent = t('nav_home');
  document.getElementById('bnav-lbl-learn').textContent = t('nav_learn');
  document.getElementById('bnav-lbl-vocab').textContent = t('nav_vocab');
  document.getElementById('bnav-lbl-quiz').textContent = t('nav_quiz');
  document.getElementById('bnav-lbl-profile').textContent = t('nav_profile');
  // Home
  document.getElementById('lbl-welcome-back').textContent = t('welcome_back');
  document.getElementById('lbl-streak').textContent = t('streak');
  document.getElementById('lbl-xp').textContent = t('xp');
  document.getElementById('lbl-daily').textContent = t('daily_goal');
  document.getElementById('lbl-learning').textContent = t('learning');
  document.getElementById('lbl-modules').textContent = t('modules_title');
  document.getElementById('btn-continue').textContent = t('btn_continue');
  // Tabs
  document.getElementById('lbl-learn-title').textContent = t('learn_title');
  document.getElementById('lbl-vocab-title').textContent = t('vocab_title');
  document.getElementById('lbl-vocab-sub').textContent = t('vocab_sub');
  document.getElementById('lbl-quiz-title').textContent = t('quiz_title');
}
